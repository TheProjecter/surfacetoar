//
//  SurfaceToAR_ServerAppDelegate.m
//  SurfaceToAR Server
//
//  Created by Jishuo Yang on 10/17/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SurfaceToAR_ServerAppDelegate.h"

@implementation SurfaceToAR_ServerAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
