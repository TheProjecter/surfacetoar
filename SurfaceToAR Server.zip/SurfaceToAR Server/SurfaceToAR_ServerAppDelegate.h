//
//  SurfaceToAR_ServerAppDelegate.h
//  SurfaceToAR Server
//
//  Created by Jishuo Yang on 10/17/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface SurfaceToAR_ServerAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
}

@property (assign) IBOutlet NSWindow *window;

@end
