//
//  ConnectMenuViewController.h
//  ConnectMenu
//
//  Created by Jishuo Yang on 10-11-05.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ConnectMenuViewController : UIViewController {

}

- (IBAction)connectPressed: (id) sender;
- (IBAction)pressDoneKey;
@end

