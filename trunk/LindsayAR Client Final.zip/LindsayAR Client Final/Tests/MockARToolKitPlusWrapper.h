//
//  MockARToolKitPlusWrapper.h
//  LindsayAR
//
//  Created by Jishuo Yang on 10-08-29.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ARToolKitPlusWrapper.h"

@interface MockARToolKitPlusWrapper : ARToolKitPlusWrapper {
	
}

@end
